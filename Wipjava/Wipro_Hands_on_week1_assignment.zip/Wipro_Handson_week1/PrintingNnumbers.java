// Write a program to print all numbers from 1 to 100 i.e. 1 2 3 4 5 6 7 . . . 98 99 100
public class PrintingNnumbers {
    public static void main(String[] args){
        for(int i=1;i<=100;i++){
            System.out.printf("%d ",i);
        }
    }
}
